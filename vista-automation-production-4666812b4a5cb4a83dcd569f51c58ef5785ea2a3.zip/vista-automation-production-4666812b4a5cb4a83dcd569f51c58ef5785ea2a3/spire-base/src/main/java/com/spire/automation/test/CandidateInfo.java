package com.spire.automation.test;

/**
 * Created by Vinay Kumar on 19-05-2015.
 */
public class CandidateInfo {

    public String value;
    public String text;
   // public List list;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

   /* public List getList() {
        return list;
    }

    public void setList(List list) {
        this.list = list;
    }*/
}
