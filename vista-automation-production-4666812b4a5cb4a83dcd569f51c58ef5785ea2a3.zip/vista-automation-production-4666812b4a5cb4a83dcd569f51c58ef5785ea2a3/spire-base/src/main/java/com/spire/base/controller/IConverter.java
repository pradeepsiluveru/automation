package com.spire.base.controller;
/**
 * Interface for convert Web/API URL
 */
public interface IConverter {
	
	public String convertURL(String url) throws Exception;
		
}

