package com.spire.base.controller;

import org.testng.ITestContext;


public interface IContexAttributeListener {
	public void load(ITestContext testNGCtx, Context mauiCtx);
}
