package com.spire.crm.admin_ui;

public class EngagementWeight {
	public String compatibility;
	public String connectFactrs;
	public String awareness;
	public String personalComm;
	public String interestLevel;
	public String broadcastComm;

	public String getCompatibility() {
		return compatibility;
	}

	public void setCompatibility(String compatibility) {
		this.compatibility = compatibility;
	}

	public String getConnectFactrs() {
		return connectFactrs;
	}

	public void setConnectFactrs(String connectFactrs) {
		this.connectFactrs = connectFactrs;
	}

	public String getAwareness() {
		return awareness;
	}

	public void setAwareness(String awareness) {
		this.awareness = awareness;
	}

	public String getPersonalComm() {
		return personalComm;
	}

	public void setPersonalComm(String personalComm) {
		this.personalComm = personalComm;
	}

	public String getInterestLevel() {
		return interestLevel;
	}

	public void setInterestLevel(String interestLevel) {
		this.interestLevel = interestLevel;
	}

	public String getBroadcastComm() {
		return broadcastComm;
	}

	public void setBroadcastComm(String broadcastComm) {
		this.broadcastComm = broadcastComm;
	}

}
