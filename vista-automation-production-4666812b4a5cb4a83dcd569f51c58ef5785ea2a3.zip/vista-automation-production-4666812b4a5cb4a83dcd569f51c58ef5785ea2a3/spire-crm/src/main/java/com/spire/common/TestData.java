package com.spire.common;

public class TestData {

	public String TestSteps;
	public String data;
	public String exception;

	public String getTestSteps() {
		return TestSteps;
	}

	public void setTestSteps(String testSteps) {
		TestSteps = testSteps;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public String getException() {
		return exception;
	}

	public void setException(String exception) {
		this.exception = exception;
	}

}
