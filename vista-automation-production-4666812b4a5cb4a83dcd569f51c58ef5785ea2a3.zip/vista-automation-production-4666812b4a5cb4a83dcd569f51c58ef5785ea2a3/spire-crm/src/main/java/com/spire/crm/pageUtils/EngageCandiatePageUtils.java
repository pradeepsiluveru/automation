package com.spire.crm.pageUtils;

import org.openqa.selenium.WebDriver;

import com.spire.crm.pages.EngageCandidatePage;

public class EngageCandiatePageUtils extends EngageCandidatePage {

	public EngageCandiatePageUtils(WebDriver driver, Boolean openurl) {
		super(driver, openurl);
	}

}
