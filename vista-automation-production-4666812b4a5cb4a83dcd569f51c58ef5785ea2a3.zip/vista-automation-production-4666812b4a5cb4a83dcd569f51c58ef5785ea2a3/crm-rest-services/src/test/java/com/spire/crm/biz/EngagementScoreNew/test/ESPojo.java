package com.spire.crm.biz.EngagementScoreNew.test;

public class ESPojo {

	private String candidateId;
	private String activityTypeInfo;
	private String benifitLevel;
	private String companyLevel;
	private String interestLevel;
	private String fitmentLevel;
	private String notes;
	private String name;

	public String getCandidateId() {
		return candidateId;
	}
	public void setCandidateId(String candidateId) {
		this.candidateId = candidateId;
	}
	public String getActivityTypeInfo() {
		return activityTypeInfo;
	}
	public void setActivityTypeInfo(String activityTypeInfo) {
		this.activityTypeInfo = activityTypeInfo;
	}
	public String getBenifitLevel() {
		return benifitLevel;
	}
	public void setBenifitLevel(String benifitLevel) {
		this.benifitLevel = benifitLevel;
	}
	public String getCompanyLevel() {
		return companyLevel;
	}
	public void setCompanyLevel(String companyLevel) {
		this.companyLevel = companyLevel;
	}
	public String getInterestLevel() {
		return interestLevel;
	}
	public void setInterestLevel(String interestLevel) {
		this.interestLevel = interestLevel;
	}
	public String getFitmentLevel() {
		return fitmentLevel;
	}
	public void setFitmentLevel(String fitmentLevel) {
		this.fitmentLevel = fitmentLevel;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}
