package com.spire.crm.activity.biz.pojos;

import java.util.List;

public class CRMHomeActivities {
	
	List<CRMHomeActivity> homeActivities;
	int totolCounts;
	
	public List<CRMHomeActivity> getHomeActivities() {
		return homeActivities;
	}
	public void setHomeActivities(List<CRMHomeActivity> homeActivities) {
		this.homeActivities = homeActivities;
	}
	public int getTotolCounts() {
		return totolCounts;
	}
	public void setTotolCounts(int totolCounts) {
		this.totolCounts = totolCounts;
	}
	
	

}
