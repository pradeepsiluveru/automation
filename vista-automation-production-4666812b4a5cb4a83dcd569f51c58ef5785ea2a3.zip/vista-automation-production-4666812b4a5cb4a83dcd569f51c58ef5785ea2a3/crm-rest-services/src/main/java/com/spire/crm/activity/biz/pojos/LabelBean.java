package com.spire.crm.activity.biz.pojos;

public class LabelBean extends spire.commons.labels.beans.LabelBean{

	public LabelBean() {
		super(null, null, null);
	}

}
