package com.spire.common;

public class EmailQueryParamPojo {
	
	private String limit;
	private String offset;
	
	public String getLimit() {
		return limit;
	}
	public void setLimit(String limit) {
		this.limit = limit;
	}
	public String getOffset() {
		return offset;
	}
	public void setOffset(String offset) {
		this.offset = offset;
	}
	

}
