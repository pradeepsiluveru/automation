package com.spire.common;

public class TestData {

	public String TestSteps;
	public String data;
	public String exception;
	public String enumData;
	public String expected;

	public String getExpected() {
		return expected;
	}

	public void setExpected(String expected) {
		this.expected = expected;
	}

	public String getEnumData() {
		return enumData;
	}

	public void setEnumData(String enumData) {
		this.enumData = enumData;
	}

	public String getTestSteps() {
		return TestSteps;
	}

	public void setTestSteps(String testSteps) {
		TestSteps = testSteps;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public String getException() {
		return exception;
	}

	public void setException(String exception) {
		this.exception = exception;
	}

}
