package com.spire.crm.restful.entity.consumers;

public class Links {

	private String rel;
	private String href;

	public void setRel(String rel) {
		this.rel = rel;
	}

	public String getRel() {
		return rel;
	}

	public void setHref(String href) {
		this.href = href;
	}

	public String getHref() {
		return href;
	}

}
