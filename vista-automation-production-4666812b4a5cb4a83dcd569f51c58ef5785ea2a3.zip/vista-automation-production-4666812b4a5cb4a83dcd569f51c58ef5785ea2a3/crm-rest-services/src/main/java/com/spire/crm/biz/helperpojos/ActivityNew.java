package com.spire.crm.biz.helperpojos;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import spire.commons.activitystream.Activity;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ActivityNew extends Activity {

}
