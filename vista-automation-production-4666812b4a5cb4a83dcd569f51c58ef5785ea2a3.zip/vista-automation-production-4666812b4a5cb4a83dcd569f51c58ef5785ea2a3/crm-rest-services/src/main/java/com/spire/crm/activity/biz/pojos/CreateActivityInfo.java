package com.spire.crm.activity.biz.pojos;

import java.util.List;

public class CreateActivityInfo {
	
	List<String> activityTypes;
	List<String> ratingTypes;
	public List<String> getActivityTypes() {
		return activityTypes;
	}
	public void setActivityTypes(List<String> activityTypes) {
		this.activityTypes = activityTypes;
	}
	public List<String> getRatingTypes() {
		return ratingTypes;
	}
	public void setRatingTypes(List<String> ratingTypes) {
		this.ratingTypes = ratingTypes;
	}
	
	

}
