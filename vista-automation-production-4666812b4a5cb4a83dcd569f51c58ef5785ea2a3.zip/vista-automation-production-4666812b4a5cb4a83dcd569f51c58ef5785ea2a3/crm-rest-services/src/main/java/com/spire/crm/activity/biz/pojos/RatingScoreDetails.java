package com.spire.crm.activity.biz.pojos;

public class RatingScoreDetails {
	
	private int RatingScore;

	public int getRatingScore() {
		return RatingScore;
	}

	public void setRatingScore(int ratingScore) {
		RatingScore = ratingScore;
	}

}
