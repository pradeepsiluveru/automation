package com.spire.crm.activity.biz.pojos;

public class CRMCommunicationDetails {
	
	private String communicationType;

	public String getCommunicationType() {
		return communicationType;
	}

	public void setCommunicationType(String communicationType) {
		this.communicationType = communicationType;
	}
	
}
