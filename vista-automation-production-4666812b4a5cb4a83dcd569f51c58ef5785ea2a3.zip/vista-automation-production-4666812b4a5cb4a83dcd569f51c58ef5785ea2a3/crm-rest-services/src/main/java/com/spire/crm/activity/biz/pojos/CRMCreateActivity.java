package com.spire.crm.activity.biz.pojos;

public class CRMCreateActivity {
	
	private String candidateId;
	private String activityTypeInfo;
	private int benifitLevel;
	private int companyLevel;
	private int interestLevel;
	private int fitmentLevel;
	private String notes;
	private String name;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCandidateId() {
		return candidateId;
	}
	public void setCandidateId(String candidateId) {
		this.candidateId = candidateId;
	}
	public String getActivityTypeInfo() {
		return activityTypeInfo;
	}
	public void setActivityTypeInfo(String activityTypeInfo) {
		this.activityTypeInfo = activityTypeInfo;
	}
	public int getBenifitLevel() {
		return benifitLevel;
	}
	public void setBenifitLevel(int benifitLevel) {
		this.benifitLevel = benifitLevel;
	}
	public int getCompanyLevel() {
		return companyLevel;
	}
	public void setCompanyLevel(int companyLevel) {
		this.companyLevel = companyLevel;
	}
	public int getInterestLevel() {
		return interestLevel;
	}
	public void setInterestLevel(int interestLevel) {
		this.interestLevel = interestLevel;
	}
	public int getFitmentLevel() {
		return fitmentLevel;
	}
	public void setFitmentLevel(int fitmentLevel) {
		this.fitmentLevel = fitmentLevel;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}

	
	
	

}
