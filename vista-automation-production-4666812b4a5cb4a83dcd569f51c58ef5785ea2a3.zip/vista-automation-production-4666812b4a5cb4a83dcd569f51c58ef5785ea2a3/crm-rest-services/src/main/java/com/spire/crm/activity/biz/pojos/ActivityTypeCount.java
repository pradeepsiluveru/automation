package com.spire.crm.activity.biz.pojos;

public class ActivityTypeCount {
	
	private String activityTypeName;
	private int count;
	
	public String getActivityTypeName() {
		return activityTypeName;
	}
	public void setActivityTypeName(String activityTypeName) {
		this.activityTypeName = activityTypeName;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}

}
