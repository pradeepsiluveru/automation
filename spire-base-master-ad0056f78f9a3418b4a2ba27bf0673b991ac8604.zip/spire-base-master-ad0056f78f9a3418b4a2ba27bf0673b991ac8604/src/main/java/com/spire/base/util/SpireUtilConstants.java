package com.spire.base.util;

/**
 * Created by Vinay Kumar on 25-05-2015.
 */
public class SpireUtilConstants {

	public static final String DOUBLE_QUOTE = "\"";
	public static final String DELIM_CHAR = ",";
	public static final String SCREENSHOT_PATH = "./src/main/resources/screenshots/";
	public static final String DOWNLOAD_PATH_PREF="C:\\downloads\\";
}
