package com.spire.base.driver.web;

public enum WebDriverMode {
	LocallyOnRC,
	ExistingGrid,
	local
}
