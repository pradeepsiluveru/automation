package com.spire.base.controller;

import org.testng.xml.XmlSuite;

public class DefaultXmlSuite extends XmlSuite{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6658243628670353825L;

}
